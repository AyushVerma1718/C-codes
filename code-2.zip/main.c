#include<stdio.h>

int main()
{
	float num1, num2 ;

	printf("Enter two floating-point numbers:\n ");
	scanf("%f %f", &num1, &num2);

	printf("Product = %.2f\n", num1*num2);

	return 0;
}